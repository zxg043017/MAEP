
python main.py --distributed # multi GPU for training with DDP

python main.py  #single GPU for training 
